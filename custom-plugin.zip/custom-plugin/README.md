# custom-plugin
A WordPress plugin that uses the Vimeo API to display videos in WordPress.
