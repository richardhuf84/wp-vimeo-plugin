<?php namespace Vimeo\Exceptions;

/**
 * ExceptionInterface
 */
interface ExceptionInterface
{

}
